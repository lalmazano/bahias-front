class Env {
  static const String apiBaseUrl = "http://34.68.247.232:8080";
}